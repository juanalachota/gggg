/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.erikaramirez;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
/**
 *
 * @author Talento Azteca 29
 */
public class Juego {
    JTextField jt;
    JLabel lb;
    JLabel lb2;
    
    private boolean play =false;
    private String[] diccionario = {"ESOTILIN","PINTAMOS","TODA","CASA","DEJAR","CAER","GOTA","PINTURA","QUEESESOOOO","TOMORROW","TOGETHER","KOUMEZ","AIKITO","ROBLOX","CARPINCHO","CAPYBARA","ÑANDU"}; //90
    
    private char[] palabra_secreta;
    private char[] palabra;
    
    int intentos = 0;
    boolean cambios=false;
    
    public Juego(){}
    
    public Juego(JTextField texto, JLabel emo, JLabel emo2){
        System.out.print("Palabra secreta: ");
        this.palabra_secreta = Random().toCharArray();        
        String s="";
        //llena un string con "_" 
        for(int i=0;i<=this.palabra_secreta.length-1;i++){
          s = s + "_";
          System.out.print(this.palabra_secreta[i]); //no haga trampa
        }      
        System.out.print("\n\n");
        
        //convierte este en un array
        this.palabra = s.toCharArray();        
        
        this.jt=texto;
        this.lb= emo;
        this.lb2= emo2;
        
        jt.setText(s);
        lb.setIcon(new javax.swing.ImageIcon("C:\\Users\\2D tu mamá XD\\Downloads\\fwd (1)\\emo0.jpg"));
        lb2.setIcon(new javax.swing.ImageIcon("C:\\Users\\2D tu mamá XD\\Downloads\\fwd (1)\\ahorcado_0.jpg")); 
        
        JOptionPane.showMessageDialog(null,"¡HEY! \n\t Tienes " + this.palabra_secreta.length + " letras y " + (this.palabra_secreta.length/2) + " intentos");
        this.play=true;
    }

    //evalua el juego de acuerdo a los caracteres que se le pase
    public void evaluar(char word){
        if(play){
        String p="";
        //controla que aun se pueda jugar
        if(this.intentos==this.palabra_secreta.length/2){ 
          // lb2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/ahorcado_6.jpg")));
           
            String s="";
            //llena un string con "_" 
            for(int i=0;i<=this.palabra_secreta.length-1;i++){
            s = s + this.palabra_secreta[i]; //no haga trampa
        }      
            lb2.setIcon(new javax.swing.ImageIcon("C:\\Users\\2D tu mamá XD\\Downloads\\fwd (1)\\ahorcado_6.jpg"));
           JOptionPane.showMessageDialog(null,"¡PERDISTE QUE BOT! \n\n\t La palabra secreta era: " + s);
        }  
        else{     
           //evalua caracter por caracter
           for(int j=0;j<=this.palabra_secreta.length-1;j++){
             //si el caracter se encuentra en la palabra secreta            
             if(this.palabra_secreta[j]==word){                
                this.palabra[j]= word;//se asigna para que se pueda ver en pantalla
                this.cambios=true;
             }          
             p = p + this.palabra[j];
           }//fin for
           //si no se produjo ningun cambio, quiere decir que el jugador se equivoco
           if(this.cambios==false){
             this.intentos+=1; //se incrementa            
            lb.setIcon(new javax.swing.ImageIcon("C:\\Users\\2D tu mamá XD\\Downloads\\fwd (1)\\emo"+this.intentos+".jpg"));            
            lb2.setIcon(new javax.swing.ImageIcon("C:\\Users\\2D tu mamá XD\\Downloads\\fwd (1)\\ahorcado_"+this.intentos+".jpg"));            
             if(this.intentos<=(this.palabra_secreta.length/2)){
                JOptionPane.showMessageDialog(null,"Te quedan " + ((this.palabra_secreta.length/2)-this.intentos) + " intentos más");
             }             
           }else{
               this.cambios=false;               
           }
           this.jt.setText(p);
           //comprobamos el estado del juego
           gano();           
         }        
       }
    }
    
    private void gano(){
        boolean win=false;
        for(int i=0;i<=this.palabra_secreta.length-1;i++){
            if(this.palabra[i]==this.palabra_secreta[i]){            
                win=true;
            }else{
                win=false;
                break;
            }
        }
        if(win){             
             JOptionPane.showMessageDialog(null,"¡GANASTE ESO TILIN!");
             
        }       
    }
    
    private String Random(){   
        int num = (int)(Math.random()*(diccionario.length));   
        return diccionario[num];
    }
}
